from setuptools import setup, find_packages

setup(
    name='my_package',
    version='1.0.0',
    description='Python package for Cloudsmith CI/CD demo',
    author='Shahid',
    packages=find_packages(),
    install_requires=[],  # Add dependencies if needed
)
