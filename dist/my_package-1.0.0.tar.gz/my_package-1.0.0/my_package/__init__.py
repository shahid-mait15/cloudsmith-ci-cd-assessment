# __init__.py

# Import specific functions or classes from the module
from .example import say_hello