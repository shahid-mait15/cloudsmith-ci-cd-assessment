# example.py

def say_hello(name):
    """
    Function to say hello to the provided name.
    """
    return f"Hello, {name}! Welcome to the Python package demo for Cloudsmith."