# My Package
This is a demo package for Cloudsmith CI/CD assessment.